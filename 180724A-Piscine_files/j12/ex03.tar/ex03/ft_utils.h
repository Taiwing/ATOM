#ifndef FT_UTILS_H
#define FT_UTILS_H
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>

int ft_pow(int a, int b);
void ft_putchar(char c);
void ft_putstr(char *str);
void ft_putnbr_base(int nbr, char *bas);

#endif
