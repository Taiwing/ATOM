#ifndef FT_PRINTS_H
#define FT_PRINTS_H
#include "ft_utils.h"

void ft_print_byte(int byte, int ascii);
void ft_print_hex(char *ptr, int l);
void ft_print_hex2(char *ptr, int l);
void ft_print_char(char *ptr, int l);

#endif
