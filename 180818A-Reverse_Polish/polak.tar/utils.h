#ifndef UTILS_H
# define UTILS_H

# include <unistd.h>

void ft_putchar(char c);
void ft_putnbr(int nb);
int ft_atoi(char **str);

#endif
