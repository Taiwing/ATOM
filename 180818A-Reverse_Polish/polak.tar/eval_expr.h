#ifndef EVAL_EXPR_H
# define EVAL_EXPR_H

# include "links.h"
# include "utils.h"

int eval_expr(char *str);

#endif
